# Validator

This is a sample validator example, which can validate data with any custom rules.
For try how this validator work, please run this command and follow and follow directions
``php index.php``
